#! /usr/bin/python

print ("build")